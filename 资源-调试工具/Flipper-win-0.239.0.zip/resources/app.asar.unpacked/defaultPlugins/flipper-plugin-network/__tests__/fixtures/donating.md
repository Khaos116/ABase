# 捐赠

MobX 是使您的项目成功的关键吗？ 使用[捐赠按钮](https://mobxjs.github.io/mobx/donate.html)分享胜利！如果你留下一个名字，它将被添加到赞助商列表。
